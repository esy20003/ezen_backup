package com.ezen.ticket.dto;

public class Content_Loc_Seat_ViewVO {
	private int cseq;
	private String title;
	private int locationnum;
	private String locationname;
	private String artist;
	private String area;
	private int price;
	private String areaimage;
	public int getCseq() {
		return cseq;
	}
	public void setCseq(int cseq) {
		this.cseq = cseq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getLocationnum() {
		return locationnum;
	}
	public void setLocationnum(int locationnum) {
		this.locationnum = locationnum;
	}
	public String getLocationname() {
		return locationname;
	}
	public void setLocationname(String locationname) {
		this.locationname = locationname;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getAreaimage() {
		return areaimage;
	}
	public void setAreaimage(String areaimage) {
		this.areaimage = areaimage;
	}
}
