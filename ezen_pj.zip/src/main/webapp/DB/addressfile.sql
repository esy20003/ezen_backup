INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-512', '서울', '강남구', '역삼2동 진달래아파트', '(10∼17동)', '446'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-918', '서울', '강남구', '역삼2동', '706∼707', '447'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-919', '서울', '강남구', '역삼2동', '708∼716', '448'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-920', '서울', '강남구', '역삼2동', '717∼724', '449'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-921', '서울', '강남구', '역삼2동', '725∼730', '450'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-514', '서울', '강남구', '역삼2동', '731∼734', '451'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-926', '서울', '강남구', '역삼2동', '754∼755', '452'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-927', '서울', '강남구', '역삼2동', '756∼768', '453'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-928', '서울', '강남구', '역삼2동', '769∼779', '454'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-515', '서울', '강남구', '역삼2동', '780∼788', '455'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-082', '서울', '강남구', '역삼2동', NULL, '456'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-080', '서울', '강남구', '역삼동', NULL, '457'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-210', '서울', '강남구', '율현동', NULL, '458'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-938', '서울', '강남구', '일원1동 도시개발아파트', NULL, '459'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-938', '서울', '강남구', '일원1동', '4', '460'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-938', '서울', '강남구', '일원1동', '362', '461'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-943', '서울', '강남구', '일원1동', '580∼610', '462'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-943', '서울', '강남구', '일원1동', '617∼641', '463'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-945', '서울', '강남구', '일원1동', '642∼676', '464'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-516', '서울', '강남구', '일원1동', '677∼687', '465'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-938', '서울', '강남구', '일원1동', '711∼712', '466'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-231', '서울', '강남구', '일원1동', NULL, '467'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-944', '서울', '강남구', '일원2동 대우아파트', NULL, '468'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-946', '서울', '강남구', '일원2동 우성7차아파트', NULL, '469'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-946', '서울', '강남구', '일원2동 한신아파트', NULL, '470'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-944', '서울', '강남구', '일원2동 현대4차아파트', '(1동)', '471'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-946', '서울', '강남구', '일원2동 현대아파트', '(10∼33동)', '472'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-944', '서울', '강남구', '일원2동', '614∼616', '473'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-946', '서울', '강남구', '일원2동', '689∼692', '474'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-232', '서울', '강남구', '일원2동', NULL, '475'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-947', '서울', '강남구', '일원본동 가람아파트', NULL, '476'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-990', '서울', '강남구', '일원본동 극동현대아파트', NULL, '477'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-991', '서울', '강남구', '일원본동 금호목련아파트', NULL, '478'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-942', '서울', '강남구', '일원본동 삼성푸른아파트', NULL, '479'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-947', '서울', '강남구', '일원본동 상록수아파트', NULL, '480'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-941', '서울', '강남구', '일원본동 청솔아파트', NULL, '481'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-942', '서울', '강남구', '일원본동 한솔아파트', NULL, '482'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-941', '서울', '강남구', '일원본동', '63', '483'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-942', '서울', '강남구', '일원본동', '214', '484'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-942', '서울', '강남구', '일원본동', '424∼443', '485'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-942', '서울', '강남구', '일원본동', '713∼714', '486'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-947', '서울', '강남구', '일원본동', '715∼717', '487'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-942', '서울', '강남구', '일원본동', '718∼729', '488'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-947', '서울', '강남구', '일원본동', '734∼735', '489'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-239', '서울', '강남구', '일원본동', NULL, '490'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-967', '서울', '강남구', '일원동 공무원아파트', NULL, '491'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-710', '서울', '강남구', '일원동 삼성의료원', NULL, '492'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-230', '서울', '강남구', '일원동', NULL, '493'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-200', '서울', '강남구', '자곡동', NULL, '494'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-762', '서울', '강남구', '청담1동 모나미빌딩', NULL, '495'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-765', '서울', '강남구', '청담1동 세신빌딩', NULL, '496'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-763', '서울', '강남구', '청담1동 은성빌딩', NULL, '497'); 
INSERT INTO address ( zip_num, sido, gugun, dong, bunji,
zip_code ) VALUES ( 
'135-761', '서울', '강남구', '청담1동 정화빌딩', NULL, '498'); 

select * from address;