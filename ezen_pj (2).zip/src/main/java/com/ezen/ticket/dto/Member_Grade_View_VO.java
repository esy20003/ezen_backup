package com.ezen.ticket.dto;

public class Member_Grade_View_VO {
	
	private int cmseq;
	private String cid;
	private String cnickname;
	private int success;
	private int grade;
	private String gname;
	private String gprice;
	
	public int getCmseq() {
		return cmseq;
	}
	public void setCmseq(int cmseq) {
		this.cmseq = cmseq;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCnickname() {
		return cnickname;
	}
	public void setCnickname(String cnickname) {
		this.cnickname = cnickname;
	}
	public int getSuccess() {
		return success;
	}
	public void setSuccess(int success) {
		this.success = success;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getGprice() {
		return gprice;
	}
	public void setGprice(String gprice) {
		this.gprice = gprice;
	}
	
}
