select * from admin;



insert into admin(id, pwd, name, phone, email) 
values('admin', 'admin', '김현우', '010-1564-7894', 'woo1@naver.com');
insert into admin(id, pwd, name, phone, email) 
values('hana', '1234', '김하나', '010-1564-7894', 'hana@naver.com');
insert into admin(id, pwd, name, phone, email) 
values('sung', '1111', '박성훈', '010-1564-7894', 'sung97@naver.com');
insert into admin(id, pwd, name, phone, email) 
values('like', '4567', '김사랑', '010-1564-7894', 'love12@naver.com');



