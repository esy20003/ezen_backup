select * from grade;

insert into grade(gseq, gname, gprice)
values(0,'Normal', 0);

insert into grade(gseq, gname, gprice)
values(1,'Bronze', 100000);

insert into grade(gseq, gname, gprice)
values(2,'Silver', 200000);

insert into grade(gseq, gname, gprice)
values(3,'Gold', 300000);

insert into grade(gseq, gname, gprice)
values(4,'Platinum', 400000);

insert into grade(gseq, gname, gprice)
values(5,'Diamonds', 500000);

