select * from locationNum;



insert into locationNum values(locationNum_seq.nextVal,'KBS부산홀');
insert into locationNum values(locationNum_seq.nextVal,'잠실 실내체육관');
insert into locationNum values(locationNum_seq.nextVal,'올림픽공원 올림픽홀');
insert into locationNum values(locationNum_seq.nextVal,'서울 잠실종합운동장 올림픽주경기장');
insert into locationNum values(locationNum_seq.nextVal,'블루스퀘어 마스터카드홀');
insert into locationNum values(locationNum_seq.nextVal,'수원종합운동장 실내체육관');
insert into locationNum values(locationNum_seq.nextVal,'백암아트홀');
insert into locationNum values(locationNum_seq.nextVal,'대구 엑스코 오디토리움');
insert into locationNum values(locationNum_seq.nextVal,'예술의전당 오페라극장');
insert into locationNum values(locationNum_seq.nextVal,'잠실야구장');
insert into locationNum values(locationNum_seq.nextVal,'수원월드컵경기장');
insert into locationNum values(locationNum_seq.nextVal,'고척스카이돔');
insert into locationNum values(locationNum_seq.nextVal,'삼성라이온즈파크');
insert into locationNum values(locationNum_seq.nextVal,'샤롯데씨어터');
insert into locationNum values(locationNum_seq.nextVal,'블루스퀘어 신한카드홀');
insert into locationNum values(locationNum_seq.nextVal,'서울 올림픽 공원 88잔디마당');
insert into locationNum values(locationNum_seq.nextVal,'더현대서울 6층');
insert into locationNum values(locationNum_seq.nextVal,'인사센트럴뮤지엄');


select * from locationNum;