/**
 * 
 */
 
 function go_apply(){
	 bodyChoose.applyButton.action='ticket.do?command=applyForm';
	 bodyChoose.applyButton.submit();
 }
 
 function go_register(){
	 bodyChoose.registerButton.action='ticket.do?command=registerForm';
	 bodyChoose.registerButton.submit();
 }