insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <백작>', '아트원씨어터 2관', '2023년 6월 5일(월) - 2023년 8월 27일(일)', '2023년 5월 22일(월)', '이승현 외', '뮤지컬', '13');

insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <더 테일 에이프릴 풀스>', '서경대학교 공연예술센터 스콘2관', '2023년 6월 7일(수) ~ 2023년 8월 27일(일)', '2023년 5월 22일(월)', '최석진 외', '뮤지컬', '14')

insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <빠리빵집>', '세종문화회관 S씨어터', '2023년 05월 13일(토) ~ 2023년 6월 25일(일)', '2023년 5월 22일(월)', '고훈정 외', '뮤지컬', '7')

insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <백작>', '아트원씨어터 2관', '2023년 6월 5일(월) - 2023년 8월 27일(일)', '2023년 5월 22일(월)', '이승현 외', '뮤지컬', '13')

insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <백작>', '아트원씨어터 2관', '2023년 6월 5일(월) - 2023년 8월 27일(일)', '2023년 5월 22일(월)', '이승현 외', '뮤지컬', '13')

insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <백작>', '아트원씨어터 2관', '2023년 6월 5일(월) - 2023년 8월 27일(일)', '2023년 5월 22일(월)', '이승현 외', '뮤지컬', '13')

insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <백작>', '아트원씨어터 2관', '2023년 6월 5일(월) - 2023년 8월 27일(일)', '2023년 5월 22일(월)', '이승현 외', '뮤지컬', '13')

insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <백작>', '아트원씨어터 2관', '2023년 6월 5일(월) - 2023년 8월 27일(일)', '2023년 5월 22일(월)', '이승현 외', '뮤지컬', '13')

insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <백작>', '아트원씨어터 2관', '2023년 6월 5일(월) - 2023년 8월 27일(일)', '2023년 5월 22일(월)', '이승현 외', '뮤지컬', '13')

insert into content(cseq, title, location, cdate, tdate, seat, artist, category, age)
values(SEQ_CONTENT_CSEQ, '뮤지컬 <백작>', '아트원씨어터 2관', '2023년 6월 5일(월) - 2023년 8월 27일(일)', '2023년 5월 22일(월)', '이승현 외', '뮤지컬', '13')

select * from user_sequences;