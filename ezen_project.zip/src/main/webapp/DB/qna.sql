insert into qna_board(qseq, mseq, title, content, id)
values (qna_board_qseq.nextval, 1, '종료된 티켓팅', '종료된 티켓팅도 취켓팅으로 가능한가요?','dsan');

insert into qna_board(qseq, mseq, title, content, id)
values(qna_board_qseq.nextval, 2, '문의합니다', '수고비는 자리에 따라 조정되나요?', 'bts2');

insert into qna_board(qseq, mseq, title, content, id)
values(qna_board_qseq.nextval, 3, '문의드립니다~', '사이트에 없는 티켓팅도 가능한가요?', 'gangji');

insert into qna_board(qseq, mseq, title, content, id)
values(qna_board_qseq.nextval, 4, '수고비 문의', '취소하면 전액 환불 해주시나요?', 'jrong');

insert into qna_board(qseq, mseq, title, content, id)
values(qna_board_qseq.nextval, 5, '환불문의', '아직 환불이 안 들어왔는데 언제쯤 들어올까요?', 'kinder');

insert into qna_board(qseq, mseq, title, content, id)
values(qna_board_qseq.nextval, 6, '문의합니다!', '원하는 열과 구역을 정확히 지정할 수 있을까요?', 'babo');

insert into qna_board(qseq, mseq, title, content, id)
values(qna_board_qseq.nextval, 7, '취소 문의', '취소하고 싶어요 ㅠㅠ 취소 가능할까요?', 'gildong');

insert into qna_board(qseq, mseq, title, content, id)
values(qna_board_qseq.nextval, 8, '문의드려용!!', '꼭 성공 부탁드리겠습니당!!?', 'work');

insert into qna_board(qseq, mseq, title, content, id)
values(qna_board_qseq.nextval, 9, '아이디 변경 문의', '아이디와 비번을 변경할 수 있을까요?', 'sleep');

insert into qna_board(qseq, mseq, title, content, id)
values(qna_board_qseq.nextval, 10, '문희드립니당', '수고비도 조정이 가능한가요?', 'java');

select * from REVIEW_BOARD
select * from MEMBER
select * from qna_board
select * from seat


