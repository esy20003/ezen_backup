package com.ezen.ticket.controller.action.anr;

import java.io.IOException;

import com.ezen.ticket.controller.action.Action;
import com.ezen.ticket.controller.action.HttpServletRequest;
import com.ezen.ticket.controller.action.HttpServletResponse;
import com.ezen.ticket.controller.action.ServletException;

public class ApplyAndRegisterAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
